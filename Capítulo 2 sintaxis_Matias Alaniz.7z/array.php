<?php
function filtrarMenoresQue($array, $limite) {
    return array_filter($array, function($valor) use ($limite) {
        return $valor < $limite;
    });
}

// Ejemplo de uso
$numeros = [1, 5, 8, 12, 3, 7];
$limite = 6;
$resultado = filtrarMenoresQue($numeros, $limite);

print_r($resultado); // Salida: Array ( [0] => 1 [1] => 5 [4] => 3 )
?>
