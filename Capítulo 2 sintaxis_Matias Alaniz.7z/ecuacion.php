<?php
function resolverEcuacionSegundoGrado($a, $b, $c) {
    // Calcular el discriminante
    $discriminante = $b * $b - 4 * $a * $c;

    // Verificar si el discriminante es negativo
    if ($discriminante < 0) {
        return "No hay soluciones reales.";
    } else {
        // Calcular las dos soluciones
        $solucion1 = (-$b + sqrt($discriminante)) / (2 * $a);
        $solucion2 = (-$b - sqrt($discriminante)) / (2 * $a);
        return "Las soluciones son: $solucion1 y $solucion2";
    }
}

// Ejemplo de uso
$a = 1;
$b = -3;
$c = 2;
echo resolverEcuacionSegundoGrado($a, $b, $c);
?>
