<?php
function resolverEcuacionCuadratica($a, $b, $c) {
    // Calculamos el discriminante
    $discriminante = $b * $b - 4 * $a * $c;

    // Si el discriminante es negativo, no hay soluciones reales
    if ($discriminante < 0) {
        return FALSE;
    }

    // Calculamos las dos soluciones
    $solucion1 = (-$b + sqrt($discriminante)) / (2 * $a);
    $solucion2 = (-$b - sqrt($discriminante)) / (2 * $a);

    // Devolvemos las soluciones en un array
    return array($solucion1, $solucion2);
}

// Ejemplo de uso
$a = 1;
$b = -3;
$c = 2;
$resultado = resolverEcuacionCuadratica($a, $b, $c);

if ($resultado === FALSE) {
    echo "No hay soluciones reales.";
} else {
    echo "Las soluciones son: " . implode(", ", $resultado);
}
?>
