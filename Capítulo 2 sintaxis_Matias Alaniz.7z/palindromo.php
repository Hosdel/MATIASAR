<?php
function esPalindromo($cadena) {
    // Normaliza la cadena: convierte a minúsculas y elimina caracteres no alfanuméricos
    $cadenaLimpia = strtolower(preg_replace("/[^A-Za-z0-9]/", '', $cadena));
    
    // Invierte la cadena normalizada
    $cadenaInvertida = strrev($cadenaLimpia);
    
    // Compara la cadena normalizada con su versión invertida
    return $cadenaLimpia === $cadenaInvertida;
}

// Ejemplo de uso
$cadena = "A man, a plan, a canal, Panama";
if (esPalindromo($cadena)) {
    echo "La cadena \"$cadena\" es un palíndromo.";
} else {
    echo "La cadena \"$cadena\" no es un palíndromo.";
}
?>
